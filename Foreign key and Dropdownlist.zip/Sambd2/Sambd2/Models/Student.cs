﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sambd2.Models
{
    public class Student
    {
        public int StudentId { get; set; }

        public int UserdemoId { get; set; }
        public virtual Userdemo Userdemo { get; set; }

        public string Sname { get; set; }
        public string Semail { get; set; }

        public Gender Genderlist { get; set; }
    }

    public enum Gender
    {
        Male,
        Female
    }
}