﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Sambd2.Models
{
    public class Userc:DbContext
    {
        public Userc():base("con")
        {
            DropCreateDatabaseIfModelChanges<Userc> d = new DropCreateDatabaseIfModelChanges<Userc>();
            Database.SetInitializer<Userc>(d);
       
        }
        public DbSet<Userdemo> User{ get; set;}
    }
}