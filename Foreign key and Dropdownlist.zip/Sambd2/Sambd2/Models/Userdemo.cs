﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Sambd2.Models
{
    public class Userdemo
    {
        public int UserdemoId { get; set; }

        [Required]
        [Display(Name = "Name")]
        public string name { get; set; }


        [Required]
        [Display(Name = "Username")]
        public string username { get; set; }


        [Required]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        



    }
}