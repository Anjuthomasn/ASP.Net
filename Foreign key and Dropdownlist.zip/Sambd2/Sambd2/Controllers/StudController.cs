﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sambd2.Models;

namespace Sambd2.Controllers
{
    public class StudController : Controller
    {
        private UsersContext db = new UsersContext();

        //
        // GET: /Stud/

        public ActionResult Index()
        {
            var students = db.Students.Include(s => s.Userdemo);
            return View(students.ToList());
        }

        //
        // GET: /Stud/Details/5

        public ActionResult Details(int id = 0)
        {
            Student student = db.Students.Find(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        //
        // GET: /Stud/Create

        public ActionResult Create()
        {
            ViewBag.UserdemoId = new SelectList(db.Userdemoes, "UserdemoId", "name");
            return View();
        }

        //
        // POST: /Stud/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                db.Students.Add(student);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.UserdemoId = new SelectList(db.Userdemoes, "UserdemoId", "name", student.UserdemoId);
            return View(student);
        }

        //
        // GET: /Stud/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Student student = db.Students.Find(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserdemoId = new SelectList(db.Userdemoes, "UserdemoId", "name", student.UserdemoId);
            return View(student);
        }

        //
        // POST: /Stud/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Student student)
        {
            if (ModelState.IsValid)
            {
                db.Entry(student).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.UserdemoId = new SelectList(db.Userdemoes, "UserdemoId", "name", student.UserdemoId);
            return View(student);
        }

        //
        // GET: /Stud/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Student student = db.Students.Find(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        //
        // POST: /Stud/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Student student = db.Students.Find(id);
            db.Students.Remove(student);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}