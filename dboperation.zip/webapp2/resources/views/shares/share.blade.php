<table border=1>
	<tr>
		<td>Id</td>
		<td>Title</td>
		<td>Body</td>
		<td>Edit</td>
		<td>Delete</td>
	</tr>
	
		@foreach($share as $value)
		<tr>
		<td>{{$value->id}}</td>
		<td>{{$value->title}}</td>
		<td>{{$value->body}}</td>
	</tr>
	@endforeach
</table>