<!DOCTYPE html>
<html>
<head>
	<title>Create</title>
</head>
<body>
	<form method="post" action="{{route('shares.store')}}">
		@csrf
		<table border="2">
			<tr>
				<td>Title</td>
				<td><input type="text" name="title1"></td>
			</tr>
			<tr>
				<td>Body</td>
				<td><input type="text" name="body1"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="title" value="Click"></td>
			</tr>
		</table>
	</form>

</body>
</html>