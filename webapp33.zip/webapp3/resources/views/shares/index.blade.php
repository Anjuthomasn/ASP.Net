<table border="1">
	<tr>
		<td>id</td>
		<td>Title</td>
		<td>body</td>
		<td>Edit</td>
		<td>Delete</td>

	</tr>
	@foreach($share as $value)
	<tr>
		<td>{{$value->id}}</td>
		<td>{{$value->title}}</td>
		<td>{{$value->body}}</td>
		<td><a href="{{route('shares.edit',$value->id)}}">Edit</td>
			<td>
			<form action="{{route('shares.destroy',$value->id)}}" method="post">
				@csrf
				@method('DELETE')
				<button type="submit">Delete</button>
			</form>
		</td>
	</tr>
	@endforeach
</table>
