<!DOCTYPE html>
<html>
<head>
	<title>Create</title>
</head>
<body>
<form method="post" action="{{route('shares.update',$value->id)}}">
	@method('PATCH')
	@csrf
	<table border="2">

		<tr>
			<td>Title</td>
			<td><input type="text" value="{{$value->title}}" name="title"/> </td>
		</tr>
		<tr>
		<td>body</td>
		<td><input type="text" value="{{$value->body}}" name="body"/> </td>
	     </tr>
	     <tr>
	     	<td></td>
	     	<td><input type="submit" name="title" value="click"></td>
	     </tr>
	     

	</table>
</form>
</body>
</html>