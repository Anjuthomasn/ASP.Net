<!DOCTYPE html>
<html>
<head>
	<title>Create</title>
</head>
<body>
<form method="post" action="<?php echo e(route('shares.update',$value->id)); ?>">
	<?php echo method_field('PATCH'); ?>
	<?php echo csrf_field(); ?>
	<table border="2">

		<tr>
			<td>Title</td>
			<td><input type="text" value="<?php echo e($value->title); ?>" name="title"/> </td>
		</tr>
		<tr>
		<td>body</td>
		<td><input type="text" value="<?php echo e($value->body); ?>" name="body"/> </td>
	     </tr>
	     <tr>
	     	<td></td>
	     	<td><input type="submit" name="title" value="click"></td>
	     </tr>
	     

	</table>
</form>
</body>
</html>