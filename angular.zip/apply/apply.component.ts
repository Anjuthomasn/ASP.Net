import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.css']
})
export class ApplyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  registraion(f: NgForm){
    this.error='';
    this.success='';
    this.registraion.store(this.student).subscibe
  }

}
