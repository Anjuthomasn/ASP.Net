import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { RegistrationService } from '../registration.service';
import { Student } from '../student';

@Component({
  selector: 'app-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.css']
})
export class ApplyComponent implements OnInit {
student= new Student();
  error='';
success='';
isRegistred=false;
  constructor(private reg:RegistrationService) {
   }

  ngOnInit() {
  }
  registraion(f: NgForm){
    this.error='';
    this.success='';
    this.reg.store(this.student).subscribe(
      data=>{
        // this.student=data;
        this.success='Registered Successfully';
        // this.isRegistered=true;
        // console.log(this.success);
        f.reset();
      
      },
      (err)=>{this.error="error occured";
     // this.isRegistered= false;
      }
    );
  }

}
