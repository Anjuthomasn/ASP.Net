export class Student{
    name:string;
    email:string;
    password:string;
     id?:number;
    constructor()
    {

    }
}