import { Component, OnInit } from '@angular/core';
import { collectExternalReferences } from '@angular/compiler';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user:any;
  collapse:boolean=true;
  constructor() { 
    this.user={name:'ANJU THOMAS',
  job:'Software Developer',
  address:'Kannur',
  phone:
  ['9526194454','0887733']
  };
  }
  toggle(){
    this.collapse=!this.collapse;
  }
  ngOnInit() {
  }

}
