import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hello',
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css']
})
export class HelloComponent implements OnInit {
  // message:string="hello";
  message:string=new Date().toDateString();
  no:number=10;
  add(a:number,b:number){
   return a+b;}
  

  constructor() { }

  ngOnInit() {
  }

}
